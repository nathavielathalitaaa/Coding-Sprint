<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | password reset controller
    |--------------------------------------------------------------------------
    |
    | this controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;
}
