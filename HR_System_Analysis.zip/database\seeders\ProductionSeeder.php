<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use App\Models\User;
use App\Models\EmployeeProfile;
use App\Models\SuratType;
use Spatie\Permission\PermissionRegistrar;

class ProductionSeeder extends Seeder
{
    public function run()
    {
        // STEP 1: Clear all test/dummy data
        DB::statement('SET FOREIGN_KEY_CHECKS=0');

        // Clear transactional data (keep structure)
        DB::table('document_approvals')->truncate();
        DB::table('surats')->truncate();
        DB::table('absensis')->truncate();
        DB::table('notifications')->truncate();
        DB::table('jadwal_shifts')->truncate();

        // Clear dummy users — keep only users with real emails
        // Delete users where email ends with @test.com, @company.com, @hris.test, @sinergihotel.com
        // BUT keep the first admin/hr user (id=1 or lowest id)
        DB::table('users')
            ->where('id', '>', 1)
            ->whereIn(DB::raw('SUBSTRING_INDEX(email, "@", -1)'), [
                'test.com', 'company.com', 'hris.test', 'sinergihotel.com'
            ])
            ->delete();

        // Clear employee profiles of deleted users
        DB::table('employee_profiles')
            ->whereNotIn('user_id', DB::table('users')->pluck('id'))
            ->delete();

        DB::statement('SET FOREIGN_KEY_CHECKS=1');

        // STEP 2: Ensure roles exist
        $roles = ['hr', 'supervisor', 'staff'];
        foreach ($roles as $role) {
            Role::firstOrCreate(
                ['name' => $role, 'guard_name' => 'web']
            );
        }

        // STEP 3: Ensure admin HR account exists
        $admin = User::firstOrCreate(
            ['email' => 'admin@sinergihotel.com'],
            [
                'name' => 'Admin HR',
                'password' => bcrypt('Sinergi@2026'),
                'user_id' => 'SIN-001',
                'status' => 'aktif',
                'role_name' => 'hr',
            ]
        );
        if (!$admin->hasRole('hr')) {
            $admin->assignRole('hr');
        }
        // Create profile if not exists
        EmployeeProfile::firstOrCreate(
            ['user_id' => $admin->id],
            ['jabatan' => 'hr', 'status_pernikahan' => 'belum_menikah']
        );

        // STEP 4: Ensure default surat types exist
        // Only insert if table is empty
        if (SuratType::count() === 0) {
            $this->call(SuratTypeSeeder::class);
        }

        // STEP 5: Ensure position_types have Sinergi data
        DB::table('position_types')->truncate();
        DB::table('position_types')->insert([
            ['position' => 'Front Office'],
            ['position' => 'Housekeeping'],
            ['position' => 'Food & Beverage'],
            ['position' => 'Engineering & Maintenance'],
            ['position' => 'Security'],
            ['position' => 'Accounting & Finance'],
            ['position' => 'Human Resources'],
            ['position' => 'Marketing & Sales'],
            ['position' => 'Purchasing'],
            ['position' => 'General Manager'],
            ['position' => 'Supervisor'],
            ['position' => 'Staff Umum'],
        ]);

        // STEP 6: Ensure user_types have proper data
        DB::table('user_types')->truncate();
        DB::table('user_types')->insert([
            ['type_name' => 'Active'],
            ['type_name' => 'Inactive'],
            ['type_name' => 'Probation'],
            ['type_name' => 'Contract'],
            ['type_name' => 'Permanent'],
        ]);

        // STEP 7: Clear storage test files
        // Delete test PDFs from final-pdf folder
        // Keep folder structure, just empty the files
        $dirs = [
            storage_path('app/public/final-pdf'),
            storage_path('app/public/surat/covers'),
        ];
        foreach ($dirs as $dir) {
            if (is_dir($dir)) {
                $files = glob($dir . '/*');
                foreach ($files as $file) {
                    if (is_file($file)) unlink($file);
                }
            }
        }

        // STEP 8: Clear permission cache
        app()[PermissionRegistrar::class]->forgetCachedPermissions();

        // Print summary
        $this->command->info('=== Production Setup Complete ===');
        $this->command->info('Admin HR: admin@sinergihotel.com');
        $this->command->info('Password: Sinergi@2026');
        $this->command->info('Total users remaining: ' . User::count());
        $this->command->warn('REMIND HR to change password after first login!');
    }
}
